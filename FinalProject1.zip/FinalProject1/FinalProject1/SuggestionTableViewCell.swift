//
//  SuggestionTableViewCell.swift
//  Nike+Research
//
//  Created by Duc Tran on 3/19/17.
//  Copyright © 2017 Developers Academy. All rights reserved.
//

import UIKit


class SuggestionTableViewCell : UITableViewCell
{
    @IBOutlet weak var collectionView: UICollectionView!

}
