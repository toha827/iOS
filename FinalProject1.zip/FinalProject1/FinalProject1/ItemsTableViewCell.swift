//
//  ItemsTableViewCell.swift
//  FinalProject1
//
//  Created by Dana  Zholdykhairova on 4/21/18.
//  Copyright © 2018 Dana  Zholdykhairova. All rights reserved.
//

import UIKit

class ItemsTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBOutlet weak var imageV: UIImageView!
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var price: UILabel!
    
    var item: itemm! {
        didSet {
            self.updateUI()
        }
    }
    func updateUI()
    {
        imageV.image = item.images?.first
        Name.text = item.name
        if let cost = item.price {
            price.text = "$\(cost)"
        } else {
            price.text = ""
        }
    }
}



