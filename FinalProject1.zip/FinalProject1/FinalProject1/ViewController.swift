    import UIKit
    import Firebase
    import FirebaseAuth
    class ViewController: UIViewController {
    
        @IBOutlet weak var image1: UIView!
        
        @IBOutlet weak var button1: UIButton!
        override func viewDidLoad() {
            super.viewDidLoad()
            
            button1.layer.cornerRadius = 10
            button1.setTitleColor(UIColor.white, for: .normal)
            
         button1.layer.borderWidth = 1.0   // толщина обводки
            button1.layer.borderColor = (UIColor(red: 10.0/255.0, green: 116.0/255.0, blue: 419.0/255.0, alpha: 0.5)).cgColor // цвет обводки
       
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
        @IBAction func done_button(_ sender: UIButton) {
            Auth.auth().createUser(withEmail: email_field.text!, password: password_field.text!, completion: { (user, error) in
                self.indicator.stopAnimating()
                if error == nil{
                    user?.sendEmailVerification(completion: { (error) in
                        if error == nil{
                            print(user?.isEmailVerified as Any)
                            self.messageLabel.text = "Check your email.We sent you a verification link"
                            self.messageLabel.textColor = UIColor.green
                        }
                    })
                    print("DSADsdasdasdasdasdasdasdasd")
                    
                    let formatter = DateFormatter()
                    formatter.dateFormat = "dd.MM.yyyy"
                    
                    
                    let date = self.DateOfBirth.date
                    let result = formatter.string(from: date)
                    let user = User.init(self.name_field.text!, self.surname_field.text!, result,self.email_field.text!)
                    self.dbRef?.childByAutoId().setValue(user.toJSONFormat())
                    self.performSegue(withIdentifier: "signInSegue", sender: self)
                }else{
                    self.messageLabel.text = "Something is wrong!"
                    self.messageLabel.textColor = UIColor.red
                }
            })
        }
}

