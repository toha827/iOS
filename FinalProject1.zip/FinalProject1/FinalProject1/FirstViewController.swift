//
//  FirstViewController.swift
//  FinalProject1
//
//  Created by Dana  Zholdykhairova on 4/21/18.
//  Copyright © 2018 Dana  Zholdykhairova. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var btn1: UIButton!
    @IBOutlet weak var btn2: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        btn1.layer.cornerRadius = 10
        btn1.setTitleColor(UIColor.white, for: .normal)
        
        btn1.layer.borderWidth = 3.0   // толщина обводки
        btn1.layer.borderColor = (UIColor(red: 242.0/255.0, green: 116.0/255.0, blue: 119.0/255.0, alpha: 1.0)).cgColor // цвет обводки
        btn2.layer.cornerRadius = 10
        btn2.setTitleColor(UIColor.white, for: .normal)
        
        btn2.layer.borderWidth = 3.0   // толщина обводки
        btn2.layer.borderColor = (UIColor(red: 242.0/255.0, green: 116.0/255.0, blue: 119.0/255.0, alpha: 1.0)).cgColor // цвет обводки
    }

  
    

   

}
