//
//  HomeTableViewController.swift
//  FinalProject1
//
//  Created by Dana  Zholdykhairova on 4/21/18.
//  Copyright © 2018 Dana  Zholdykhairova. All rights reserved.
//

import UIKit

class HomeTableViewController: UITableViewController {
    var items: [itemm]?
    
    struct Storyboard {
        static let feedShoeCell = "Items"
        static let showShoeDetail = "itemDetail"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        items = itemm.fetchItems()
        self.tableView.reloadData()
        self.tableView.estimatedRowHeight = tableView.rowHeight
        self.tableView.rowHeight = UITableViewAutomaticDimension
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == Storyboard.showShoeDetail {
            if let shoeDetailTVC = segue.destination as? DeatailTableViewController {
                let selectedShoe = self.items?[(sender as! IndexPath).row]
                shoeDetailTVC.item = selectedShoe
            }
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    

    
}
extension HomeTableViewController
{
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let item = items {
            return item.count
        } else {
            return 0
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Storyboard.feedShoeCell, for: indexPath) as! ItemsTableViewCell
        
        cell.item = self.items?[indexPath.row]
        cell.selectionStyle = .none
        
        return cell
    }
    
}
extension HomeTableViewController
{
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: Storyboard.showShoeDetail, sender: indexPath)
    }
}
