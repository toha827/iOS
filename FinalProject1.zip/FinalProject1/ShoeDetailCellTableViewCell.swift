//
//  ShoeDetailCellTableViewCell.swift
//  FinalProject1
//
//  Created by Dana  Zholdykhairova on 4/21/18.
//  Copyright © 2018 Dana  Zholdykhairova. All rights reserved.
//

import UIKit

class ShoeDetailCellTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
