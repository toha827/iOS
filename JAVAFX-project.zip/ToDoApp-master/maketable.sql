CREATE TABLE Tasks (TITLE 		   TEXT     NOT NULL, 
                    LOCATION       TEXT     NOT NULL,
					NOTES		   TEXT		NOT NULL,
					TIMING		   DATETIME PRIMARY KEY NOT NULL);
					
